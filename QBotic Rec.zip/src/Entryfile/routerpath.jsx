const publicPath = '/blue/';

export const routeCodes = {
  HOME: publicPath,
  LOGIN: `${ publicPath }login`,
  REGISTER: `${ publicPath }register`,
};