
import Tasks from '../MainPage/Employees/Projects/tasks/tasks.jsx';

export default [  
   {
      path: 'tasks',
      component: Tasks
   }
]